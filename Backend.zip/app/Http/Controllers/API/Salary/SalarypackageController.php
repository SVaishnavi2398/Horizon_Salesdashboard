<?php

namespace App\Http\Controllers\API\Salary;
use DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Salary\Salarypackage;

class SalarypackageController extends Controller
{
    public function index()
    {
        $salarypackage = Salarypackage::all();
        $salarypackage = DB::table('salary_package')
                        ->join('users', 'users.user_id', '=', 'salary_package.user_id')
                        //->join('teams', 'teams.team_id', '=', 'team_leaders.team_id')
                        //->join('team_status','team_status.team_status_id','=','team_leaders.status')
                        ->select('users.firstname','users.middlename','users.lastname', 'salary_package.*')
                        ->where('boolean_value', '1')
                        ->orderBy('salary_package.updated_at','DESC')
                        ->get();
		return response()->json($salarypackage);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $newSalarypackage = new Salarypackage([
			
			'user_id' => $request->get('user_id'),
            'from_date' => $request->get('from_date'),
            'to_date' => $request->get('to_date'),
            'basic_pay' => $request->get('basic_pay'),
            'variable_pay' => $request->get('variable_pay'),
            'yearly_bonus' => $request->get('yearly_bonus'),
            'monthly_salary' => $request->get('monthly_salary'),
            'yearly_salary' => $request->get('yearly_salary'),
            'remark' => $request->get('remark'),
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      
            $request->validate([
            
                'user_id' => 'required',
                'from_date' => 'required',
                'to_date' => '',
                'basic_pay' => 'required',
                'variable_pay' => 'required',
                'yearly_bonus' => 'required',
                'monthly_salary' => 'required',
                'yearly_salary' => 'required',
                'remark' => 'required'
            ]);
    
            $newSalarypackage = new Salarypackage([
            
                'user_id' => $request->get('user_id'),
                'from_date' => $request->get('from_date'),
                'to_date' => $request->get('to_date'),
                'basic_pay' => $request->get('basic_pay'),
                'variable_pay' => $request->get('variable_pay'),
                'yearly_bonus' => $request->get('yearly_bonus'),
                'monthly_salary' => $request->get('monthly_salary'),
                'yearly_salary' => $request->get('yearly_salary'),
                'remark' => $request->get('remark')
            ]);
    
            $newSalarypackage->save();
    
            return response()->json($newSalarypackage);
        
    
          
           
       
    }
 
    public function getState(Request $request)
    {
    $user_id = $request->user_id;
    $subprojectsModel = new Salarypackage();
    $data = $subprojectsModel->getState($user_id);
    return response()->json($data);
}
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
    public function show($salary_package_id)
    {
        $salarypackage = Salarypackage::findOrFail($salary_package_id);
		return response()->json($salarypackage);


    }
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($salary_package_id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $salary_package_id)
    {

        $salarypackage = Salarypackage::findOrFail($salary_package_id);
		
		$salarypackage = Salarypackage::find($salary_package_id);
        $salarypackage->update($request->all());
        return $salarypackage;

        // $teamleaders = Teamleaders::findOrFail($team_leader_id);

        // $teamleaders = Teamleaders::find($team_leader_id);
        // $teamleaders->status = $request->input('status');
        // $teamleaders->update();
        
        // return response()->json($teamleaders);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($salary_package_id)
    {
        $salarypackage = Salarypackage::findOrFail($salary_package_id);
		//$salarypackage->delete();

        $salarypackage = Salarypackage::find($salary_package_id);
        if ($salarypackage) {
            $salarypackage->boolean_value = 0;
            $salarypackage->save();
            return $salarypackage;
        }

		//return response()->json($salarypackage::all());
    }
}
