<?php

namespace App\Models\Salary;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Advancesalary extends Model
{
    use HasFactory;
	
	protected $table = 'advance_salary';

	protected $primaryKey = 'advance_salary_id';
	
	protected $fillable = [
        //'slug',
        'user_id',
		'advanced_paid_date',
		'amount',
		'emi_amount',
		'repaid_amount',
        'balance_amount',
        'status',
        'remark'
      ];
}
