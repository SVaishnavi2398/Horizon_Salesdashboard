<?php

namespace App\Models\Salary;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Advanceemi extends Model
{
    use HasFactory;

    protected $table = 'advance_emi_details';

	protected $primaryKey = 'emi_id';

    protected $fillable = [
        //'slug',
        'advance_salary_id',
		'emi_deduct_date',
		'emi_amount',
        'remark'
      ];
}
